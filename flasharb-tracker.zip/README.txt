# FlashArb BEP20 Tracker

## Cara Deploy ke Vercel (via HP / PC)
1. Buka [https://vercel.com](https://vercel.com)
2. Login (pakai Google atau GitHub)
3. Klik “+ New Project” → “Import...” → “Upload ZIP”
4. Upload file `flasharb-tracker.zip`
5. Tunggu 1 menit — web akan otomatis online!

Website menampilkan harga real-time dari Binance & DexScreener.
Token default: BNB, CAKE, USDT, USDC, WBNB.
